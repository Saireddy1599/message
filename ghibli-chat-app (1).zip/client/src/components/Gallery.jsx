import React from "react";

export function Gallery() {
  const images = [
    "https://ghibliapi.vercel.app/images/1.jpg",
    "https://ghibliapi.vercel.app/images/2.jpg",
    "https://ghibliapi.vercel.app/images/3.jpg"
  ];

  return (
    <div className="mb-6">
      <h2 className="text-xl font-semibold mb-2">Ghibli Gallery</h2>
      <div className="grid grid-cols-3 gap-2">
        {images.map((src, idx) => (
          <img
            key={idx}
            src={src}
            alt={`Ghibli ${idx}`}
            className="rounded-xl shadow-md"
          />
        ))}
      </div>
    </div>
  );
}
