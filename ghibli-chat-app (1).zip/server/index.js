import express from "express";
import cors from "cors";
import http from "http";
import { Server as SocketServer } from "socket.io";

const app = express();
const server = http.createServer(app);
const io = new SocketServer(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  }
});

app.use(cors());
app.use(express.json());

// Chat events
io.on("connection", (socket) => {
  console.log("New user connected: " + socket.id);

  socket.on("chat message", (msg) => {
    io.emit("chat message", msg);
  });

  socket.on("disconnect", () => {
    console.log("User disconnected: " + socket.id);
  });
});

// Contact form API (stub)
app.post("/contact", (req, res) => {
  const { name, email, message } = req.body;
  console.log("Contact received:", { name, email, message });
  res.status(200).json({ message: "Contact form submitted successfully" });
});

const PORT = process.env.PORT || 5000;
server.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});
